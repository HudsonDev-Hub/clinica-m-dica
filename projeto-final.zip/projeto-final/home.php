<h1>Seja bem vindo </h1>

<h1>ORIENTAÇÕES</h1
>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        ESPECIALIDADES
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Atendimentos oferecidos:

- Clínica Médica 
- Geriatria
- Cardiologia
- Reumatologia
- Dermatologia
- Neurologia
- Pediatria
- Ginecologia e Obstetrícia / Pré-Natal
- Psiquiatria
- Endocrinologia
- Academia Escola de Educação Física
- Psicologia
- Fisioterapia
- Nutrição
- Exames Laboratoriais</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
       FAXETARIA
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body"> Atendemos pacientes com idade igual ou superior a 14 anos, exceto pediatra que não tem restrição de idade.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
       AVISOS
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Para atendimento com (Reumatologia, Cardiologia, Neurologia, Dermatologia, Endocrinologia e Geriatria) é necessário encaminhamento médico.</div>
    </div>
  </div>
</div>
</div>
</div>